import 'package:flutter/material.dart';
import 'package:test_app/login/login_view.dart';
import 'package:test_app/student_list/student_list_controller.dart';
import 'package:get/get.dart';

class StudentListView extends StatefulWidget {
  final String token;

  const StudentListView({super.key, required this.token});

  @override
  State<StudentListView> createState() => _StudentListViewState();
}

class _StudentListViewState extends State<StudentListView> {
  @override
  Widget build(BuildContext context) {
    StudentListController studentListController =
        Get.put(StudentListController());
    studentListController.getStudentList(widget.token);
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          spacing: 10,
          children: [
            Row(
              children: [
                IconButton(
                  onPressed: () {
                    Get.back();
                  },
                  icon: Icon(
                    Icons.arrow_back,
                  ),
                ),
                Spacer(),
                InkWell(
                  onTap: () {
                    Get.offAll(LoginView());
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Center(
                        child: Row(
                          children: [
                            Icon(
                              Icons.logout,
                              color: Colors.white,
                            ),
                            Text(
                              'Logout',
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
            Expanded(
              child: Obx(() {
                return ListView.builder(
                  itemCount: studentListController.schoolList.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        color: Colors.grey.withValues(
                          alpha: 0.3,
                        ),
                        width: MediaQuery.sizeOf(context).width * 0.5,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            spacing: 8,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.info_outline,
                                    color: Colors.deepOrange,
                                  ),
                                  Spacer(),
                                  Checkbox(value: false, onChanged: (value) {})
                                ],
                              ),
                              Center(
                                child: Text(
                                  studentListController
                                      .schoolList[index].schoolName,
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: Image.asset(
                                      'assets/images/School 1.png',
                                      width: 60,
                                      height: 60,
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Total Students : ${studentListController.schoolList[index].totalStudents}',
                                        ),
                                        Text(
                                          'With photo : ${studentListController.schoolList[index].withImageStudents}',
                                        ),
                                        Text(
                                          'Without photo : ${studentListController.schoolList[index].noImageStudents}',
                                        ),
                                        Text(
                                          'Status Approved : ${studentListController.schoolList[index].approvedStudents}',
                                        ),
                                        Text(
                                          'Status Pending : ${studentListController.schoolList[index].pendingStudents}',
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                              Row(
                                children: [
                                  Container(
                                    width: 100,
                                    decoration: BoxDecoration(
                                        color: Colors.deepOrange,
                                        borderRadius: BorderRadius.circular(8)),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.edit,
                                          color: Colors.white,
                                        ),
                                        Text(
                                          'View',
                                          style: TextStyle(color: Colors.white),
                                        )
                                      ],
                                    ),
                                  ),
                                  Spacer(),
                                  Container(
                                    width: 100,
                                    decoration: BoxDecoration(
                                        color: Colors.deepOrange,
                                        borderRadius: BorderRadius.circular(8)),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.view_agenda,
                                          color: Colors.white,
                                        ),
                                        Text(
                                          'Edit',
                                          style: TextStyle(color: Colors.white),
                                        )
                                      ],
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}
