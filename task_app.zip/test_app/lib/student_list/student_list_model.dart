// To parse this JSON data, do
//
//     final school = schoolFromJson(jsonString);

import 'dart:convert';

School schoolFromJson(String str) => School.fromJson(json.decode(str));

String schoolToJson(School data) => json.encode(data.toJson());

class School {
  int status;
  bool success;
  String message;
  List<Datum> data;

  School({
    required this.status,
    required this.success,
    required this.message,
    required this.data,
  });

  factory School.fromJson(Map<String, dynamic> json) => School(
    status: json["status"],
    success: json["success"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "success": success,
    "message": message,
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  String id;
  String? userName;
  String? password;
  String contactNumber;
  bool active;
  bool deleted;
  String schoolName;
  String schoolContactPersonName;
  String? assignToDistributor;
  String schoolAddress;
  List<StudentField> studentFields;
  List<EmployeeField> employeeFields;
  DateTime createdAt;
  List<DistributoDetail> distributoDetails;
  int totalStudents;
  int noImageStudents;
  int withImageStudents;
  int approvedStudents;
  int pendingStudents;
  int printedStudents;
  String name;
  String? email;
  String? image;
  String? assignToSchool;

  Datum({
    required this.id,
    this.userName,
    this.password,
    required this.contactNumber,
    required this.active,
    required this.deleted,
    required this.schoolName,
    required this.schoolContactPersonName,
    required this.assignToDistributor,
    required this.schoolAddress,
    required this.studentFields,
    required this.employeeFields,
    required this.createdAt,
    required this.distributoDetails,
    required this.totalStudents,
    required this.noImageStudents,
    required this.withImageStudents,
    required this.approvedStudents,
    required this.pendingStudents,
    required this.printedStudents,
    required this.name,
    this.email,
    this.image,
    this.assignToSchool,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"],
    userName: json["userName"],
    password: json["password"],
    contactNumber: json["contactNumber"],
    active: json["active"],
    deleted: json["deleted"],
    schoolName: json["schoolName"],
    schoolContactPersonName: json["schoolContactPersonName"],
    assignToDistributor: json["assignToDistributor"],
    schoolAddress: json["schoolAddress"],
    studentFields: List<StudentField>.from(json["studentFields"].map((x) => StudentField.fromJson(x))),
    employeeFields: List<EmployeeField>.from(json["employeeFields"].map((x) => EmployeeField.fromJson(x))),
    createdAt: DateTime.parse(json["createdAt"]),
    distributoDetails: List<DistributoDetail>.from(json["distributoDetails"].map((x) => DistributoDetail.fromJson(x))),
    totalStudents: json["totalStudents"],
    noImageStudents: json["noImageStudents"],
    withImageStudents: json["withImageStudents"],
    approvedStudents: json["approvedStudents"],
    pendingStudents: json["pendingStudents"],
    printedStudents: json["printedStudents"],
    name: json["name"],
    email: json["email"],
    image: json["image"],
    assignToSchool: json["assignToSchool"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "userName": userName,
    "password": password,
    "contactNumber": contactNumber,
    "active": active,
    "deleted": deleted,
    "schoolName": schoolName,
    "schoolContactPersonName": schoolContactPersonName,
    "assignToDistributor": assignToDistributor,
    "schoolAddress": schoolAddress,
    "studentFields": List<dynamic>.from(studentFields.map((x) => x.toJson())),
    "employeeFields": List<dynamic>.from(employeeFields.map((x) => x.toJson())),
    "createdAt": createdAt.toIso8601String(),
    "distributoDetails": List<dynamic>.from(distributoDetails.map((x) => x.toJson())),
    "totalStudents": totalStudents,
    "noImageStudents": noImageStudents,
    "withImageStudents": withImageStudents,
    "approvedStudents": approvedStudents,
    "pendingStudents": pendingStudents,
    "printedStudents": printedStudents,
    "name": name,
    "email": email,
    "image": image,
    "assignToSchool": assignToSchool,
  };
}

class DistributoDetail {
  String id;
  String distributorName;

  DistributoDetail({
    required this.id,
    required this.distributorName,
  });

  factory DistributoDetail.fromJson(Map<String, dynamic> json) => DistributoDetail(
    id: json["_id"],
    distributorName: json["distributorName"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "distributorName": distributorName,
  };
}

class EmployeeField {
  bool image;
  bool contactNumber;
  bool email;
  bool employeeId;
  bool designation;
  bool placeOfPosting;
  bool employeeName;
  bool employeesFatherOrHusbandName;
  bool dateOfBirth;
  bool aadharNumber;
  bool panNumber;
  bool sdId;
  bool subject;
  bool employeePresentAddress;
  bool employeePermanentAddress;
  bool bloodGroup;
  bool dateOfJoining;
  bool dateOfRetirement;
  bool approvalStatus;
  bool other1;
  bool other2;
  bool other3;
  bool other4;
  bool other5;
  String id;
  bool? gender;

  EmployeeField({
    required this.image,
    required this.contactNumber,
    required this.email,
    required this.employeeId,
    required this.designation,
    required this.placeOfPosting,
    required this.employeeName,
    required this.employeesFatherOrHusbandName,
    required this.dateOfBirth,
    required this.aadharNumber,
    required this.panNumber,
    required this.sdId,
    required this.subject,
    required this.employeePresentAddress,
    required this.employeePermanentAddress,
    required this.bloodGroup,
    required this.dateOfJoining,
    required this.dateOfRetirement,
    required this.approvalStatus,
    required this.other1,
    required this.other2,
    required this.other3,
    required this.other4,
    required this.other5,
    required this.id,
    this.gender,
  });

  factory EmployeeField.fromJson(Map<String, dynamic> json) => EmployeeField(
    image: json["image"],
    contactNumber: json["contactNumber"],
    email: json["email"],
    employeeId: json["employeeId"],
    designation: json["designation"],
    placeOfPosting: json["placeOfPosting"],
    employeeName: json["employeeName"],
    employeesFatherOrHusbandName: json["employeesFatherOrHusbandName"],
    dateOfBirth: json["dateOfBirth"],
    aadharNumber: json["aadharNumber"],
    panNumber: json["panNumber"],
    sdId: json["sdId"],
    subject: json["subject"],
    employeePresentAddress: json["employeePresentAddress"],
    employeePermanentAddress: json["employeePermanentAddress"],
    bloodGroup: json["bloodGroup"],
    dateOfJoining: json["dateOfJoining"],
    dateOfRetirement: json["dateOfRetirement"],
    approvalStatus: json["approvalStatus"],
    other1: json["other1"],
    other2: json["other2"],
    other3: json["other3"],
    other4: json["other4"],
    other5: json["other5"],
    id: json["_id"],
    gender: json["gender"],
  );

  Map<String, dynamic> toJson() => {
    "image": image,
    "contactNumber": contactNumber,
    "email": email,
    "employeeId": employeeId,
    "designation": designation,
    "placeOfPosting": placeOfPosting,
    "employeeName": employeeName,
    "employeesFatherOrHusbandName": employeesFatherOrHusbandName,
    "dateOfBirth": dateOfBirth,
    "aadharNumber": aadharNumber,
    "panNumber": panNumber,
    "sdId": sdId,
    "subject": subject,
    "employeePresentAddress": employeePresentAddress,
    "employeePermanentAddress": employeePermanentAddress,
    "bloodGroup": bloodGroup,
    "dateOfJoining": dateOfJoining,
    "dateOfRetirement": dateOfRetirement,
    "approvalStatus": approvalStatus,
    "other1": other1,
    "other2": other2,
    "other3": other3,
    "other4": other4,
    "other5": other5,
    "_id": id,
    "gender": gender,
  };
}

class StudentField {
  bool image;
  bool admissionOrEnrollNumber;
  bool email;
  bool studentFieldClass;
  bool section;
  bool studentName;
  bool dateOfBirth;
  bool contactNumber;
  bool gender;
  bool fathersName;
  bool mothersName;
  bool aadharNumber;
  bool studentAddress;
  bool nicId;
  bool penNumber;
  bool ubiCode;
  bool subject;
  bool house;
  bool session;
  bool bloodGroup;
  bool modeOfTransport;
  bool other1;
  bool other2;
  bool other3;
  bool other4;
  bool other5;
  String id;

  StudentField({
    required this.image,
    required this.admissionOrEnrollNumber,
    required this.email,
    required this.studentFieldClass,
    required this.section,
    required this.studentName,
    required this.dateOfBirth,
    required this.contactNumber,
    required this.gender,
    required this.fathersName,
    required this.mothersName,
    required this.aadharNumber,
    required this.studentAddress,
    required this.nicId,
    required this.penNumber,
    required this.ubiCode,
    required this.subject,
    required this.house,
    required this.session,
    required this.bloodGroup,
    required this.modeOfTransport,
    required this.other1,
    required this.other2,
    required this.other3,
    required this.other4,
    required this.other5,
    required this.id,
  });

  factory StudentField.fromJson(Map<String, dynamic> json) => StudentField(
    image: json["image"],
    admissionOrEnrollNumber: json["admissionOrEnrollNumber"],
    email: json["email"],
    studentFieldClass: json["class"],
    section: json["section"],
    studentName: json["studentName"],
    dateOfBirth: json["dateOfBirth"],
    contactNumber: json["contactNumber"],
    gender: json["gender"],
    fathersName: json["fathersName"],
    mothersName: json["mothersName"],
    aadharNumber: json["aadharNumber"],
    studentAddress: json["studentAddress"],
    nicId: json["nicId"],
    penNumber: json["penNumber"],
    ubiCode: json["ubiCode"],
    subject: json["subject"],
    house: json["house"],
    session: json["session"],
    bloodGroup: json["bloodGroup"],
    modeOfTransport: json["modeOfTransport"],
    other1: json["other1"],
    other2: json["other2"],
    other3: json["other3"],
    other4: json["other4"],
    other5: json["other5"],
    id: json["_id"],
  );

  Map<String, dynamic> toJson() => {
    "image": image,
    "admissionOrEnrollNumber": admissionOrEnrollNumber,
    "email": email,
    "class": studentFieldClass,
    "section": section,
    "studentName": studentName,
    "dateOfBirth": dateOfBirth,
    "contactNumber": contactNumber,
    "gender": gender,
    "fathersName": fathersName,
    "mothersName": mothersName,
    "aadharNumber": aadharNumber,
    "studentAddress": studentAddress,
    "nicId": nicId,
    "penNumber": penNumber,
    "ubiCode": ubiCode,
    "subject": subject,
    "house": house,
    "session": session,
    "bloodGroup": bloodGroup,
    "modeOfTransport": modeOfTransport,
    "other1": other1,
    "other2": other2,
    "other3": other3,
    "other4": other4,
    "other5": other5,
    "_id": id,
  };
}
