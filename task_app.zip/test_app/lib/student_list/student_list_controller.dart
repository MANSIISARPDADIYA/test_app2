import 'dart:convert';

import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:test_app/student_list/student_list_model.dart';

import '../apis/apis.dart';

class StudentListController extends GetxController {
  RxList<Datum> schoolList = <Datum>[].obs;
  Map<String, dynamic> data = {};

  Future<void> getStudentList(String token) async {
    var headers = {
      'Authorization': token,
    };
    var request = http.Request('GET', Uri.parse(Api().getData));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      final response2 = await response.stream.bytesToString();

      // Parse the response into a map
      final Map<String, dynamic> jsonResponse = json.decode(response2);

      // Clear the previous list
      schoolList.clear();

      // Check if "data" is available and is a list
      if (jsonResponse.containsKey('data') && jsonResponse['data'] is List) {
        // Parse and add each item to the schoolList
        jsonResponse['data'].forEach((item) {
          schoolList.add(Datum.fromJson(item));
        });
      }
    } else {
      print(response.reasonPhrase);
    }
  }

}
