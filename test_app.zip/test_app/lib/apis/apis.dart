class Api {
  final String loginApi = 'http://15.206.189.192:8100/api/auth/login/v1';
  final String getData = 'http://15.206.189.192:8100/api/school/admin/list/v1';
}
